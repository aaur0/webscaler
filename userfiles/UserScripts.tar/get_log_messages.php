<?php
if (file_exists("/var/www/python.log"))
  echo nl2br(file_get_contents("/var/www/python.log"));
?>

