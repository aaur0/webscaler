<?
$ip=<IPADDRESS>;
$database="db";
$username="root";
$password="root";
?>

