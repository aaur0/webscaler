<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Cloud Hosting</title>

<link rel="stylesheet" type="text/css" href="demo1.css" />


</head>

<body>
<div id="div-statdata" >

<?
session_start();
require_once 'functions.php';
hbar();
echo "</div>";
  if(isset($_SESSION['email']))
  {
   $email=$_SESSION['email'];
   $conn=connect();
    $custName=str_replace("@","_",$_SESSION['email']);
    $custName=str_replace(".","_",$custName);
   $sql="select * from instances where email='".$custName."' order by date desc";
   $result=mysql_query($sql) or die(mysql_error());
   $row=mysql_fetch_array($result);
    if(mysql_num_rows($result))
    {
      echo "<table id='table1' >";
      echo"<caption>Status</caption>";
      echo "<tr  valign='top'><td class='header'><b>Instance Type</b></td><td class='header'><b>IP Address</b> </td><td class='header'><b> DNS Name</b></td><td class='header'><b>Created At</b></td><td class='header'>Launch</td></tr>";
      for($i=0;$i<mysql_num_rows($result); $i++)
      {
       if($i%2){
       echo "<tr class='even'>";
       }else{
       echo "<tr class='odd'>";
       }
        if($row['type']=='mysql')
        {
          $launch=$row['dns']."/phpmyadmin";
        }else{
          $launch=$row['dns'];
        }
          #<a href='http://www.".$launch."' target='_blank'>Launch</a>
        echo "<td class='data'>".$row['type']."</td><td  class='data'>".$row['ip']."</td><td  class='data'>".$row['dns']."</td><td  class='data'>".$row['date']."</td><td  class='data'><a href='http://".$launch."' target='_blank'><font color='black'>Launch</font></a></td>";
       echo "</tr>";
       $row=mysql_fetch_array($result);
      }
       echo "</table>";
    }else{
    echo "<div id='info'> Either you have not deployed artifacts or your deployment is in progress...Please wait </div>";

    }
  }else{
         echo "<script>window.location='index.php?action=login';</script>";
   
       }
?>
</div>
</body>
</html>
