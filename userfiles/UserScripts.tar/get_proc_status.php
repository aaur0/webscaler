<?php
  require_once("./common.php");
  $bgpid = $_GET['bgpid'];

  if (is_proc_running($bgpid)) {
    $result['Status'] = 0;
    $result['Running'] = 1;
    $result['Message'] = 'Process is still running';
  } else {
    $result['Status'] = 0;
    $result['Running'] = 0;
    $result['Message'] = "Process is finished. {$bgpid}";
  }
echo json_encode($result);
?>

