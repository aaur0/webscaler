<?php
function connect() {
               require_once 'dbconfig.php';
               $mydbh=mysql_connect($ip, $username, $password)or die("Could not connect: ".mysql_error());
               $conn=mysql_select_db($database,$mydbh) or die(mysql_error());

               //Connect to database
               return $conn;

}

function hbar(){
?>

  <p> Welcome <?echo $_SESSION['fname']; ?> </p>
<table id='navtable'>
 <tr>
    <td class='navhead'><a href='index.php'>Upload Panel</a></td>
    <td class='navhead'><a href='status.php'>Status</a></td>
    <td class='navhead'><a href='index.php?action=logout'>Logout</a></td>
 </tr>
</table><br><br>
<?
}
function showUploadBox(){
echo "<table id='table1'><form method='post' enctype='multipart/form-data' action='fileUpload.php'>
      <tr><td colspan='2' class='upload' align='center'>Upload Section</td></tr>
      <tr class='even'><td class='data'>Artifact to upload</td><td> <input type='file' size='20' name='filename'></td></tr>
      <tr class='odd'><td class='data'>Schema file to upload</td><td> <input type='file' size='20' name='schema'> </td></tr>
      <tr class='even'><td class='data'>Data file to upload</td><td> <input type='file' size='20' name='data'> </td></tr>
      <tr class='last'><td colspan='2' align='center'><input type='hidden' name='upload' value='1'><input type='submit' value='Upload' name='submit'></td></tr>
      </form></table>";
}

function loginbox(){
 echo "<form  action='index.php' method='post'>
<table class='loginbox'  >
    <tr>
        <td class='reglogin'>EmailId</td><td><input type='text' name='email'></td>


        <td class='reglogin'>Password</td><td><input type='password' name='passwd'></td>


        <td><input type='hidden' name='login' value='1'></td><td  align='center'><input type='Submit' class='submit'  value=\"Login\"></td>
    </tr>
    <tr>
     <td colspan='2' align='right' class='reglogin'><a href='forgotPassword.php'><font color='black'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Forgot your password?</font></a></td>
    </tr>
</table>
   </form>";
}

function forgotPasswordBox(){
echo "<form id=\"passwordForm\" action=\"forgotPassword.php\" method=\"post\">
<table align='center'>
    <tr>
        <td>EmailId</td><td><input type=\"text\" name=\"email\"></td>
   </tr>
    <tr>
        <td> New Password</td><td><input type=\"password\" name=\"passwd\"></td>
   </tr>
   <tr>
        <td>Confirm New Password</td><td><input type=\"password\" name=\"new_passwd\"></td>
   </tr>

    <tr>
        <td><input type='hidden' name='forgotPassword' value='1'></td><td  align='center'><input type='Submit' class='submit'  value=\"Update Password\"></td>
   </tr>

</table></form>";


}
function registerbox(){
echo "
<table >
 <form  action='index.php' method='post'>
   <tr>
        <td class='reglogin'>First Name</td><td><input type='text'class='text' name='fname'></td>
   </tr>
    <tr>
        <td class='reglogin'>Last Name</td><td><input type='text' class='text' name='lname'></td>
   </tr>
    <tr>
        <td class='reglogin'>Email Id</td><td><input type='text' class='text' name='email'></td>
   </tr>
   <tr>
        <td class='reglogin'>Password</td><td><input type='password' class='text'  name='passwd'></td>
   </tr>

    <tr>
        <td><input type='hidden' name='register' value='1'></td><td  align='center'><input type='Submit' class='submit'  value='Sign Up'></td>
   </tr>
</form>
</table>
";

}


function showbox(){

           echo "<table  class='center'  ><tr><td >";
           loginbox();
           echo "</td></tr><tr><td align='center'><br><br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;New User Sign Up here</td></tr><tr><td align='right'>";
           registerbox();
           echo "</td></tr></table>";

}
?>
