<?php
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Creating a Facebook-like Registration Form with jQuery</title>

<link rel="stylesheet" type="text/css" href="demo.css" />


</head>

<body>

<div id="div-regForm" >


<form id="regForm" action="submit.php" method="post">
<table>
   <tr>
        <td>FirstName</td><td><input type="text" name="fname"></td>
   </tr>
    <tr>
        <td>LastName</td><td><input type="text" name="lname"></td>
   </tr>
    <tr>
        <td>EmailId</td><td><input type="text" name="email"></td>
   </tr>
   <tr>
        <td>Password</td><td><input type="password" name="passwd"></td>
   </tr>

    <tr>
        <td colspan='2' align='center'><input type='Submit'  value="Sign Up"></td>
   </tr>

</table>

</form>

</div>

</body>
</html>
