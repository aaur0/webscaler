<?php
session_start();
require_once 'functions.php';
if(isset($_SESSION['email']))
{ 
   showUploadBox();
   if(isset($_POST['upload']) && $_POST['upload']==1)
   {
   uploadScript();
   }
}else{
      echo "<script>window.location='index.php?action=login'</script>";
     }

function uploadScript(){
   
  // Configuration - Your Options
      $allowed_filetypes = array('.tar');//These will be the types of file that will pass the validation.
      $max_filesize = 5242880000000; // Maximum filesize in BYTES (currently 0.5MB).
      #$upload_path = './files/'; // The place the files will be uploaded to (currently a 'files' directory).
 
   $filename = $_FILES['filename']['name']; // Get the name of the file (including file extension).
   $schemaname = $_FILES['schema']['name']; // Get the name of the file (including file extension).
   $dataname = $_FILES['data']['name']; // Get the name of the file (including file extension).
   $ext = substr($filename, strpos($filename,'.'), strlen($filename)-1); // Get the extension from the filename.
   $ext1 =substr($schemaname, strpos($schemaname,'.'), strlen($schemaname)-1); // Get the extension from the filename 
   $ext2 =substr($dataname, strpos($dataname,'.'), strlen($dataname)-1); // Get the extension from the filename 
   // Check if the filetype is allowed, if not DIE and inform the user.
   if($filename =="" || $schemaname =="")
   {
    echo '<script type="text/javascript">' . "\n";
            echo 'window.location="index.php?action=upload_artifact";';
            echo '</script>';

   }
   $dir=str_replace("@","_",$_SESSION['email']);
   $dir=str_replace(".","_",$dir);
  
   `sudo mkdir -p /var/www/files/$dir`;
   `sudo chmod 777 /var/www/files/$dir`;
   $upload_path="/var/www/files/".$dir."/"; 
   
   if(!in_array($ext,$allowed_filetypes))
      die('The file you attempted to upload is not allowed.');
 
   // Now check the filesize, if it is too large then DIE and inform the user.
   if(filesize($_FILES['filename']['tmp_name']) > $max_filesize)
      die('The file you attempted to upload is too large.');
 
   // Check if we can upload to the specified path, if not DIE and inform the user.
   if(!is_writable($upload_path))
      die('You cannot upload to the specified directory, please CHMOD it to 777.');
    
   #if(move_uploaded_file($_FILES['schema']['tmp_name'],$upload_path .$_SESSION['email']."_".$schemaname))

  if(move_uploaded_file($_FILES['schema']['tmp_name'],$upload_path."tables.sql"))
   {
       echo "Schema.sql uploaded";

   }else{
       echo "Issue with schema.sql $_";
   }

   #if(move_uploaded_file($_FILES['data']['tmp_name'],$upload_path .$_SESSION['email']."_".$dataname))
   if(move_uploaded_file($_FILES['data']['tmp_name'],$upload_path."data.sql"))
   {
        echo "Data.sql uploaded";
   }else{
        echo "Issue with data.sql";
  }

   // Upload the file to your specified path.
   #if(move_uploaded_file($_FILES['filename']['tmp_name'],$upload_path .$_SESSION['email']."_".$filename))
   if(move_uploaded_file($_FILES['filename']['tmp_name'],$upload_path."webserver.tar"))
   {
       $conn=connect();    /// creating database connection.....
       $sql="select * from db.plan where email='".$_SESSION['email']."'"; 
       $result=mysql_query($sql); 
       echo "<a href='index.php?action=logout'>Logout</a></script>";
       if(mysql_num_rows($result)==0)
        {
          $sql="insert into plan (email,upload_status) values('".$_SESSION['email']."','1')"; echo $sql;
          $result=mysql_query($sql);
          //mysql_close($conn);
          echo 'Your file upload was successful'; // It worked.
        }else{
             //echo "<script>window.location=index.php?action=uploaded</script>";
             echo "Your artifacts have been updated!!"; 
        }
         mysql_close($conn);
          echo '<script type="text/javascript">' . "\n";
            echo 'window.location="index.php?action=uploaded";';
            echo '</script>';
       //echo "<script>window.location=plan.php</script>";
   }
      else{
           echo 'There was an error during the file upload.  Please try again.'; // It failed :(.
           //echo "<script>window.location=plan.php</script>";
          }
 echo "<script>window.location=plan.php</script>";
}

?>
