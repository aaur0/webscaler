<?php
session_start();
require_once 'fileUpload.php';
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Cloud Hosting</title>

<link rel="stylesheet" type="text/css" href="demo.css" />


</head>

<body>

<?php


if(isset($_SESSION['email']))
{

 if(isset($_POST['plan_type']))
 {
  $path="/root/anand3/copyfiles/ec2agent/";
  echo "<div id='success'> ".$_POST['plan']." has been selected</div>";
  $conn=connect();
  $sql="insert into plan (email,planname) values ('".$_SESSION['email']."','".$_POST['plan']."')";
  $result=mysql_query($sql);
  mysql_close($conn);
   //showUploadBox();

  //1. Creating LoadBalancer Instance format:  Create type<0|1|2> InstanceName
  #exec("./q.sh   >/dev/null &");
  $cmd=$path."awsmethod.py create ".$_SESSION['email']." ".$_POST['plan'];
  
  exec("python $cmd   >loadbalancer.log 2>&1 &");
  //2. Creating WebServer1 Instance <Same Format>
  //3. Creating WebServer2 Instance <Same Format>
  //4. Creating MySQL server Instance <Same Format>
  //5. Preparing LoadBalancer
  //6. Preparing WebServer1
  //7. Preparing WebServer2
  //8. Preparing Mysql
  //9. Deploying Artifacts
  //10. Starting Services
  

 }
?>
<a href='index.php?action=logout'>Logout</a>
  <!---<div id='div-block'>---!>
     <table>
        <tr>
           <td><div id='div-block'>Col1</div></td>
           <td><div id='div-block'>Col2</div></td>
           <td><div id='div-block'>Col3</div></td>
        </tr>
     </table>
     <form method='post' action='plan.php'>
      Select Plan <input type='radio' name='plan' value='0'>Plan1
                  <input type='radio' name='plan' value='1'>Plan2
                  <input type='radio' name='plan' value='2'>Plan3
                  <input type='hidden' name='plan_type' value='1'>
                  <input type='Submit' class='submit'  value="Submit">
     </form> 
<?
}else{
echo '<script type="text/javascript">' . "\n";
            echo 'window.location="index.php?action=login";';
            echo '</script>';
}

?>
