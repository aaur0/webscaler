<?php
require_once 'functions.php';
session_start();
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Cloud Hosting</title>

<link rel="stylesheet" type="text/css" href="demo1.css" />


</head>

<body>

<!----<div id="div-regForm"> ---!>

  <?
    if(isset($_GET['action']) && ($_GET['action']=="uploaded"))
    { 
     hbar();
     echo "<div id='success'>Your artifacts have been uploaded successfully!!</div>";
       $custName=str_replace("@","_",$_SESSION['email']);
       $custName=str_replace(".","_",$custName);
      $cmd="sudo /root/installer/shellscripts/createLampStack  create $custName /root/installer/pythonscripts/ 0";
      $outputfile="/var/www/deployment.log";
      $pidfile="/var/www/deployment.log";
      
      exec(sprintf("%s > %s 2>&1 & echo $! >> %s", $cmd, $outputfile, $pidfile));
      #`sudo /root/installer/shellscripts/createLampStack  create cust1 /root/installer/pythonscripts/ 1 2>&1 &`;
    }elseif(isset($_GET['action']) && ($_GET['action']=="upload_artifact"))
    { hbar();
        echo "<div id='err'>Upload Artifacts first</div>";
        require_once 'fileUpload.php';
    }
    else if(isset($_GET['action']) && ($_GET['action']=="logout"))
    {
      session_destroy();
      echo "<div id='success'>You Have been logged out successfully</div>";
      showbox();
    } else if(isset($_GET['action']) && ($_GET['action']=="login"))
    {
     echo "<div id='err'>Login first</div>";
      showbox();
    }
    
    else if($_POST['login']==1 || isset($_SESSION['email']))
    {
        if(isset($_SESSION['email']))
        {
           hbar();
          #echo "<div id='success'>Welcome ".$_SESSION['fname']."<a href='status.php'>Status</a><a href='index.php?action=logout'>Logout</a></div>";
          require_once 'fileUpload.php'; 
        }else{
        $fname = addslashes($_POST['fname']);
        $lname = addslashes($_POST['lname']);
        $email = addslashes($_POST['email']);
        $passwd= addslashes(md5($_POST['passwd']));

        $conn=connect();
        $sql="select fname,lname from user where email='$email' and passwd='$passwd'";
        $result=mysql_query($sql);
        $row=mysql_fetch_array($result);
        $rows=mysql_num_rows($result);
        if($rows==1)
        {
          $_SESSION['email']=$email;
          $_SESSION['fname']=$row['fname'];
          $_SESSION['lname']=$row['lname'];
          echo "Welcome ".$_SESSION['fname']." <a href='index.php?action=logout'>Logout</a>";
            #require_once 'fileUpload.php';
            echo '<script type="text/javascript">';
            echo 'window.location="status.php";';
            echo '</script>';
        }else{
        echo "<div id='err'>Invalid Username or Password. Please try again</div>";
        showbox();
        }
        mysql_close($conn);   
       }            
    }
    else if($_POST['register']==1)
    {

        ### Post Variables
        $fname = addslashes($_POST['fname']);
        $lname = addslashes($_POST['lname']);
        $email = addslashes($_POST['email']);
        $passwd= addslashes(md5($_POST['passwd']));

	if(empty($fname) || empty($lname) || empty($passwd) || empty($email))
	{
          echo "<div id='err'> Please enter the mandatory field</div>";
           showbox();
        }else{
              
              if(!(preg_match("/^[\.A-z0-9_\-\+]+[@][A-z0-9_\-]+([.][A-z0-9_\-]+)+[A-z]{1,4}$/", $_POST['email'])))
              {
               echo "<div id='err'>$email is Invalid Email Id</div>";
               showbox();
              }
              else{
               $conn=connect();
               mysql_close($conn);
               $sql="select email from user where email='$email'";
	       $result=mysql_query($sql);
               $rows=mysql_num_rows($result);
               if($rows ==0)
               {
                $sql="insert into user (email,fname,lname,passwd) values ('$email','$fname','$lname','$passwd')";
                $result=mysql_query($sql);
                echo "<div id='success'>You Have been registered successfully</div>";
                  showbox();
               }else{
                echo "<div id='err'>$email has already been registered with us!!</div>";
                   showbox(); 
                    }
                 mysql_close($conn);
               }
             }
      

    }else{
            showbox();
         }
?>

<!----</div> ----!>

</body>
</html>
