<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Cloud Hosting</title>

<link rel="stylesheet" type="text/css" href="demo1.css" />


</head>

<body>

<?
session_start();
require_once 'functions.php';
  if(!isset($_SESSION['email']))
  {
     if(isset($_POST['forgotPassword'])&&($_POST['forgotPassword']==1))
     {
      $passwd=$_POST['passwd'];
      $new_passwd=$_POST['new_passwd'];
      $email=$_POST['email'];
      if($passwd == $new_passwd)
      {
       $conn=connect();
       $passwd=md5(addslashes($passwd));
       $sql="update user set passwd='$passwd' where email='$email'"; 
       $result=mysql_query($sql);
       mysql_close($conn);
       echo "<div id='success'>Password Updated successfully!!</div>";
        echo "<table align='center'><tr><td><a href='index.php'>Click here to Login</a></td></tr></table>";
      }else{
       
       echo "<div id='err'>Password Mismatch. Please try again</div>";
      }
     }
    
     forgotPasswordBox();   

  }
?>
</body>
</html>
