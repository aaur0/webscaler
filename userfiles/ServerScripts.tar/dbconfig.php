<?
$ip=<IPADDRESS>;
$database="db";
$username=<USERNAME>;
$password=<PASSWORD>;
?>

